package com.dionys.mymap.step;

public interface StepCountListener {

    void countStep();

}