package com.dionys.mymap.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dionys.mymap.R;


public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String TAG = "HomeActivity";

    private ImageView list;
    private TextView distanceText;
    private TextView timeText;

    private Spinner distanceSpinner;
    private Spinner timeSpinner;

    private Button goButton;

    private double distanceTarget;
    private int timeTarget;

    private final String[] dis_arr = {
            "1km","2km","5km"
    };

    private final String[] time_arr = {
            "1分钟","2分钟","5分钟","10分钟","20分钟"
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        init();
    }


    private void init() {
        // 设置状态栏颜色及字体颜色
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            // 设置状态栏透明
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

            // 设置状态栏字体黑色
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        distanceTarget = 1.0;
        timeTarget = 1;
        list = findViewById(R.id.list);
        distanceText = findViewById(R.id.dis_text);
        timeText = findViewById(R.id.time_text);
        goButton = findViewById(R.id.go);
        distanceSpinner = findViewById(R.id.spinner_dis);
        timeSpinner = findViewById(R.id.spinner_time);

        list.setClickable(true);
        list.setOnClickListener(this);
        goButton.setOnClickListener(this);

        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                dis_arr);

        distanceSpinner.setAdapter(adapter);
        distanceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(getApplicationContext(),"选择了"+dis_arr[position],Toast.LENGTH_SHORT).show();
                distanceText.setText("" + dis_arr[position].replace("km",""));

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                distanceText.setText("0");
            }
        });

        ArrayAdapter<String> adapterTime=new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                time_arr);

        timeSpinner.setAdapter(adapterTime);
        timeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(getApplicationContext(),"选择了"+time_arr[position],Toast.LENGTH_SHORT).show();
                timeText.setText("" + time_arr[position].replace("分钟",""));

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                timeText.setText("0");
            }
        });
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.go:
                Intent intent = new Intent(this,MapActivity.class);

                startActivity(intent);
                break;
            case R.id.list:
                Intent intent1 = new Intent(this,RecordActivity.class);
                startActivity(intent1);
                break;
        }
    }


}
