package com.dionys.mymap.step;

public interface StepValuePassListener {

    void stepChanged(int steps);

}