package com.dionys.mymap.util;

public final class Status {

    public static String SITTING = "0";
    public static String WALKING = "1";
    public static String UP = "2";
    public static String DOWN = "3";
    public static String RUNNNIG = "4";
    public static String STANDING = "6";
}
